<?
include "includes/classes.inc.php";
$page = new page("rollback");
echo $page->draw();
?>